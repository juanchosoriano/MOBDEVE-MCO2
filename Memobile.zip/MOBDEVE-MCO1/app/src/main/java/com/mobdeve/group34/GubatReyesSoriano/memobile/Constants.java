package com.mobdeve.group34.GubatReyesSoriano.memobile;

public class Constants {
    String id = "id";
    String note_texts = "note_texts";
    String create_time = "create_time";
}
