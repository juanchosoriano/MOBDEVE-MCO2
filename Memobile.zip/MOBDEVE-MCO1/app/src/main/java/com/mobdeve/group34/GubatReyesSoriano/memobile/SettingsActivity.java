package com.mobdeve.group34.GubatReyesSoriano.memobile;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
}
