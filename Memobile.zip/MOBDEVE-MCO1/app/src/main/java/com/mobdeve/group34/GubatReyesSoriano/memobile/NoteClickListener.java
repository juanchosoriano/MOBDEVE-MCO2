package com.mobdeve.group34.GubatReyesSoriano.memobile;

public interface NoteClickListener {

    void onClickItem(NoteModel noteModel);
}
